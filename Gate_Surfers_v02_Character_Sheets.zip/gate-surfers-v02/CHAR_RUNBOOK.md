# GATE SURFERS — Character Sheet Runbook (v02)

(Full style bible as provided; see projects/gate-surfers/CHAR_RUNBOOK.md in the repo for complete text.)

This zip contains the complete approved v02 generation set under the new style anchor + sheet lighting override.
